for (let index = 0; index < 20; index++) {
  alert('EU GOSTO DE ESTUDAR')
   
}