      let num=parseFloat(prompt('digite:'))
   let multi=0;
      for (let index = 1; index < 10; index++) {
         multi=num*index;
        alert('tabuada '+multi)
      }
      