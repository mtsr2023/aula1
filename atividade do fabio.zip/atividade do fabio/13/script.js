let cont=0;
for (let index = 0; index < 20; index++) {
    let a=parseFloat(prompt('digite'))
       if(a>0 && a<100){
        cont++;
       }
  }
  alert("numeros entre o intervalo de 0 à 100= "+cont)