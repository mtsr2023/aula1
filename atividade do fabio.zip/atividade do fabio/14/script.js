let cont=0,con=0,c=0;
for (let index = 0; index <20; index++) {
    let a=parseFloat(prompt('digite'))
       if(a>0 && a<100){
        cont++;
       }
       if(a>101 && a<200){
         con++;
        }
        if(a>200){
c++
        }
  }
  alert("numeros entre o intervalo de 0 à 100= "+cont)
  alert("numeros entre o intervalo de 101 à 200= "+con)
  alert("Maiore que 200= "+c)