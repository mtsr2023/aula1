  let a;
  let soma=0;
  while (true) {
    a=parseFloat(prompt("digite"))
    if(a>0){
        soma=soma+=a;
    }
     
     if(a<0){
        break;
    
     }
  }
  alert(soma)