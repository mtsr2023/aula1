let nome=prompt('ESCREVA SEU NOME')
for (let index = 0; index < 10; index++) {
  alert(nome)
    
}