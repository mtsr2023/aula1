let nome=prompt('ESCREVA SEU NOME')
let numero=prompt('DIGITE A QUANTIDADE DE VEZES :')
for (let index = 0; index < numero; index++) {
  alert(nome)
    
}