let soma=0
for (let index = 0; index < 10; index++) {
   let numero=parseFloat(prompt('DIGITE:'));
    soma=soma+=numero;
}
    alert("a soma total é="+soma)