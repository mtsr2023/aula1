let soma=0
for (let index = 0; index < 20; index++) {
   let numero=parseFloat(prompt('DIGITE AS IDADES:'));
    soma=soma+=numero;
}
    alert("SOMA DAS IDADES="+soma)