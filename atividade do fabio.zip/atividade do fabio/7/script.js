let soma=0
let cont=0;
for (let index = 0; index < 20; index++) {
   let numero=parseFloat(prompt('DIGITE AS IDADES:'));
     cont++;
    soma=soma+=numero;
}
    alert("MEDIA DAS IDADES="+(soma/cont))