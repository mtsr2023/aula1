let cont=0;
for (let index = 0; index < 20; index++) {
   let numero=parseFloat(prompt('DIGITE AS IDADES:'));

     if(numero>18){
        cont++;
     }

}
    alert("MAIORES DE 18="+ cont)