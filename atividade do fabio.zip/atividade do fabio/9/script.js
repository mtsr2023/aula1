   let idademaisnova=1000;
    let nomemaisnovo='';
    for (let index = 0; index < 10; index++) {
        let nome=prompt("digite o nome:")
        let idade=parseFloat(prompt("digite a idade:"))
        if(idade<idademaisnova){
                idademaisnova=idade
                nomemaisnovo=nome;
            }
    }

    alert("idade do mais novo "+nomemaisnovo)
   